# MechMerlin's 65_ansi layout

This is the 65% layout used by u/merlin36, host of the [MechMerlin](www.youtube.com/mechmerlin) 
YouTube channel.

It is used on his   
* [Novelkeys NK65](https://github.com/qmk/qmk_firmware/tree/master/keyboards/nk65)

### Build
To build the firmware file associated with this keymap, simply run `make your_keyboard:mechmerlin`.